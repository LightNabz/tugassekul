document.addEventListener('DOMContentLoaded', function () {
    console.log('Selamat datang di SharkOS Wiki!');
    // Bisa ditambahkan fungsi lain jika diperlukan
  });
  