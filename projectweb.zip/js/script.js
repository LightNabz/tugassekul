const hamburger = document.querySelector('.hamburger');
const navList = document.querySelector('.nav-list');

hamburger.addEventListener('click', () => {
  navList.classList.toggle('active'); // Tampilkan atau sembunyikan menu
  hamburger.classList.toggle('active'); // Animasi pada hamburger
});
  // Fungsi untuk memeriksa apakah elemen ada di dalam tampilan pengguna
  function isElementInView(el) {
    const rect = el.getBoundingClientRect();
    return rect.top <= window.innerHeight && rect.bottom >= 0;
  }

  // Mengambil semua elemen dengan kelas fade-in
  const fadeElements = document.querySelectorAll('.fade-in');

  // Fungsi untuk memeriksa elemen yang harus mendapatkan kelas visible
  function checkFadeIn() {
    fadeElements.forEach(el => {
      if (isElementInView(el)) {
        el.classList.add('visible');
      }
    });
  }

  // Menjalankan fungsi checkFadeIn saat pengguna scroll
  window.addEventListener('scroll', checkFadeIn);

  // Jalankan checkFadeIn pertama kali untuk elemen yang sudah dalam tampilan
  checkFadeIn();
